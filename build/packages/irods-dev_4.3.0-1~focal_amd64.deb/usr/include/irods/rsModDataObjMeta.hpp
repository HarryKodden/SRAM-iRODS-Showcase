#ifndef RS_MOD_DATA_OBJ_META_HPP
#define RS_MOD_DATA_OBJ_META_HPP

#include "irods/rcConnect.h"
#include "irods/modDataObjMeta.h"

int rsModDataObjMeta( rsComm_t *rsComm, modDataObjMeta_t *modDataObjMetaInp );
int _rsModDataObjMeta( rsComm_t *rsComm, modDataObjMeta_t *modDataObjMetaInp );

#endif
