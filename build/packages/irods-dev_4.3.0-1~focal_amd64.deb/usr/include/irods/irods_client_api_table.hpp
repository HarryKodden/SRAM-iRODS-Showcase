#ifndef __IRODS_CLIENT_API_TABLE_HPP__
#define __IRODS_CLIENT_API_TABLE_HPP__

#include "irods/apiHandler.hpp"

namespace irods {
    api_entry_table& get_client_api_table();
}

#endif
