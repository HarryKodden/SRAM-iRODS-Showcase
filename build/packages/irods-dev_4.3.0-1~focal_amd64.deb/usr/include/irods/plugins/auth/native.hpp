#ifndef IRODS_PLUGIN_AUTH_NATIVE_HPP
#define IRODS_PLUGIN_AUTH_NATIVE_HPP

namespace irods::experimental::auth::scheme
{
    constexpr char* native = "native";
} // namespace irods::experimental::auth::scheme

#endif // IRODS_PLUGIN_AUTH_NATIVE_HPP
