acCreateCollByAdmin(*parColl,*childColl) {
  msiCreateCollByAdmin(*parColl,*childColl);
}
