#ifndef RS_CLOSE_COLLECTION_HPP
#define RS_CLOSE_COLLECTION_HPP

#include "irods/objInfo.h"
#include "irods/dataObjInpOut.h"
#include "irods/rcConnect.h"

int rsCloseCollection( rsComm_t *rsComm, int *handleInxInp );

#endif
