#ifndef RS_SSL_END_HPP
#define RS_SSL_END_HPP

#include "irods/rcConnect.h"
#include "irods/sslEnd.h"

int rsSslEnd( rsComm_t *rsComm, sslEndInp_t *sslEndInp );

#endif
