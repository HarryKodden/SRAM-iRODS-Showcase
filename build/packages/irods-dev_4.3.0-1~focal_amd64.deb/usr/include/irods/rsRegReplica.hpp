#ifndef RS_REG_REPLICA_HPP
#define RS_REG_REPLICA_HPP

#include "irods/rcConnect.h"
#include "irods/regReplica.h"


int rsRegReplica( rsComm_t *rsComm, regReplica_t *regReplicaInp );

#endif
