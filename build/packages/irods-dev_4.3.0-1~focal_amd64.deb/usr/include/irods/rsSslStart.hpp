#ifndef RS_SSL_START_HPP
#define RS_SSL_START_HPP

#include "irods/rcConnect.h"
#include "irods/sslStart.h"

int rsSslStart( rsComm_t *rsComm, sslStartInp_t *sslStartInp );

#endif
