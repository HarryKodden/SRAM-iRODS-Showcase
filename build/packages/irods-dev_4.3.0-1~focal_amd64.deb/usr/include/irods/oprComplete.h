#ifndef OPR_COMPLETE_H__
#define OPR_COMPLETE_H__

#include "irods/rcConnect.h"

int rcOprComplete( rcComm_t *conn, int retval );

#endif
