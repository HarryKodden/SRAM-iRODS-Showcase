acSetRescSchemeForCreate {
  msiSetNoDirectRescInp("testResc");
  msiSetDefaultResc("demoResc","random");
  msiSetRescSortScheme("byRescType");
}
