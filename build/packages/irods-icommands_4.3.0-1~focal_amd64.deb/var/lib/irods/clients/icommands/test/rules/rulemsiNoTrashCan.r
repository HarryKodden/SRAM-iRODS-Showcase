acTrashPolicy {
#System control
  msiNoTrashCan;
}
