#ifndef RS_PHY_PATH_REG_HPP
#define RS_PHY_PATH_REG_HPP

#include "irods/rodsConnect.h"
#include "irods/dataObjInpOut.h"

int rsPhyPathReg( rsComm_t *rsComm, dataObjInp_t *phyPathRegInp );

#endif
