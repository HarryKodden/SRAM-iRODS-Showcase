#ifndef RS_GET_LIMITED_PASSWORD_HPP
#define RS_GET_LIMITED_PASSWORD_HPP

int rsGetLimitedPassword( rsComm_t *rsComm, getLimitedPasswordInp_t *getLimitedPasswordInp, getLimitedPasswordOut_t **getLimitedPasswordOut );
int _rsGetLimitedPassword( rsComm_t *rsComm, getLimitedPasswordInp_t *getLimitedPasswordInp, getLimitedPasswordOut_t **getLimitedPasswordOut );

#endif
