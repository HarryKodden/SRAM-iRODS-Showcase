#ifndef RS_OPEN_COLLECTION_HPP
#define RS_OPEN_COLLECTION_HPP

#include "irods/rodsConnect.h"
#include "irods/dataObjInpOut.h"

int rsOpenCollection( rsComm_t *rsComm, collInp_t *openCollInp );

#endif
