#ifndef RS_MOD_COLL_HPP
#define RS_MOD_COLL_HPP

#include "irods/rcConnect.h"
#include "irods/dataObjInpOut.h"

int rsModColl( rsComm_t *rsComm, collInp_t *modCollInp );
int _rsModColl( rsComm_t *rsComm, collInp_t *modCollInp );

#endif
