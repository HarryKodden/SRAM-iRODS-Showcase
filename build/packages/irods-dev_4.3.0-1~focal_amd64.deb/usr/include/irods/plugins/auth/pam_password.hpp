#ifndef IRODS_PLUGIN_AUTH_PAM_PASSWORD_HPP
#define IRODS_PLUGIN_AUTH_PAM_PASSWORD_HPP

namespace irods::experimental::auth::scheme
{
    constexpr char* pam_password = "pam_password";
} // namespace irods::experimental::auth::scheme

#endif // IRODS_PLUGIN_AUTH_PAM_PASSWORD_HPP
