#ifndef IRODS_HOSTNAME_HPP
#define IRODS_HOSTNAME_HPP

bool
hostname_resolves_to_local_address(const char* hostname);

#endif
