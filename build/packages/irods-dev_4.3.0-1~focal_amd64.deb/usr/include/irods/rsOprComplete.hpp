#ifndef RS_OPR_COMPLETE_HPP
#define RS_OPR_COMPLETE_HPP

#include "irods/rodsConnect.h"

int rsOprComplete( rsComm_t *rsComm, int *retval );

#endif
