acDeleteCollByAdmin(*parColl,*childColl) {
  msiDeleteCollByAdmin(*parColl,*childColl);
}
